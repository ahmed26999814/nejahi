import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import * as Notifications from "expo-notifications";
import { AppProvider, useApp } from "./src/context/AppContext";
import { t } from "./src/lib/i18n";
import type { Exam, ResultRow, SavedResult } from "./src/types";
import { HomeScreen } from "./src/screens/HomeScreen";
import { SavedScreen } from "./src/screens/SavedScreen";
import { StatsScreen } from "./src/screens/StatsScreen";
import { SettingsScreen } from "./src/screens/SettingsScreen";
import { SearchScreen } from "./src/screens/SearchScreen";
import { ResultDetailsScreen } from "./src/screens/ResultDetailsScreen";

type TabName = "home" | "saved" | "stats" | "settings";
type Route =
  | { name: "tabs" }
  | { name: "search"; exam: Exam; initialQuery?: string }
  | { name: "details"; exam: Exam; row: ResultRow; returnTo: { type: "search"; query: string } | { type: "saved" } };

const TAB_ICONS: Record<TabName, string> = {
  home: "⌂",
  saved: "★",
  stats: "▥",
  settings: "⚙",
};

function MainApp() {
  const { ready, colors, isDark, language, isOnline, exams } = useApp();
  const [tab, setTab] = useState<TabName>("home");
  const [route, setRoute] = useState<Route>({ name: "tabs" });

  useEffect(() => {
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const source = String(response.notification.request.content.data?.source || "");
      const exam = exams.find((entry) => entry.source_key === source);
      if (exam) setRoute({ name: "search", exam });
    });
    return () => subscription.remove();
  }, [exams]);

  const tabLabels = useMemo<Record<TabName, string>>(() => ({
    home: t(language, "home"),
    saved: t(language, "saved"),
    stats: t(language, "stats"),
    settings: t(language, "settings"),
  }), [language]);

  if (!ready) {
    return (
      <SafeAreaView style={[styles.loadingRoot, { backgroundColor: colors.background }]}>
        <View style={[styles.loadingLogo, { backgroundColor: colors.primary }]}><Text style={styles.loadingLogoText}>MR</Text></View>
        <ActivityIndicator color={colors.primary} size="large" />
        <Text style={[styles.loadingTitle, { color: colors.text }]}>MauriResults</Text>
      </SafeAreaView>
    );
  }

  if (route.name === "search") {
    return (
      <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]} edges={["top", "bottom"]}>
        <StatusBar style={isDark ? "light" : "dark"} />
        <SearchScreen
          exam={route.exam}
          initialQuery={route.initialQuery}
          onBack={() => setRoute({ name: "tabs" })}
          onDetails={(row, query) => setRoute({ name: "details", exam: route.exam, row, returnTo: { type: "search", query } })}
        />
      </SafeAreaView>
    );
  }

  if (route.name === "details") {
    return (
      <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]} edges={["top", "bottom"]}>
        <StatusBar style={isDark ? "light" : "dark"} />
        <ResultDetailsScreen
          exam={route.exam}
          row={route.row}
          onBack={() => {
            if (route.returnTo.type === "search") setRoute({ name: "search", exam: route.exam, initialQuery: route.returnTo.query });
            else { setTab("saved"); setRoute({ name: "tabs" }); }
          }}
        />
      </SafeAreaView>
    );
  }

  function openSaved(item: SavedResult) {
    setRoute({ name: "details", exam: item.exam, row: item.row, returnTo: { type: "saved" } });
  }

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]} edges={["top", "bottom"]}>
      <StatusBar style={isDark ? "light" : "dark"} />
      <View style={[styles.topBar, { backgroundColor: colors.surface, borderColor: colors.border, flexDirection: language === "ar" ? "row-reverse" : "row" }]}>
        <View style={[styles.brandIcon, { backgroundColor: colors.primary }]}><Text style={styles.brandIconText}>MR</Text></View>
        <View style={{ flex: 1, alignItems: language === "ar" ? "flex-end" : "flex-start" }}>
          <Text style={[styles.brandName, { color: colors.text }]}>MauriResults</Text>
          <Text style={[styles.brandSubtitle, { color: colors.muted }]}>{t(language, "nativeApp")}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: isOnline ? colors.primarySoft : `${colors.gold}20` }]}>
          <View style={[styles.statusDot, { backgroundColor: isOnline ? colors.primary : colors.gold }]} />
          <Text style={[styles.statusText, { color: isOnline ? colors.primary : colors.gold }]}>{isOnline ? "ON" : "OFF"}</Text>
        </View>
      </View>

      <View style={styles.contentArea}>
        {tab === "home" ? <HomeScreen onExam={(exam, initialQuery) => setRoute({ name: "search", exam, initialQuery })} /> : null}
        {tab === "saved" ? <SavedScreen onOpen={openSaved} /> : null}
        {tab === "stats" ? <StatsScreen /> : null}
        {tab === "settings" ? <SettingsScreen /> : null}
      </View>

      <View style={[styles.bottomBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        {(Object.keys(TAB_ICONS) as TabName[]).map((name) => {
          const active = tab === name;
          return (
            <Pressable
              key={name}
              onPress={() => setTab(name)}
              accessibilityRole="tab"
              accessibilityState={{ selected: active }}
              style={({ pressed }) => [styles.tabButton, { backgroundColor: active ? colors.primary : "transparent", opacity: pressed ? 0.8 : 1 }]}
            >
              <Text style={[styles.tabIcon, { color: active ? "#FFFFFF" : colors.muted }]}>{TAB_ICONS[name]}</Text>
              <Text style={[styles.tabLabel, { color: active ? "#FFFFFF" : colors.muted }]} numberOfLines={1}>{tabLabels[name]}</Text>
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <MainApp />
      </AppProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loadingRoot: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14 },
  loadingLogo: { width: 82, height: 82, borderRadius: 26, alignItems: "center", justifyContent: "center" },
  loadingLogoText: { color: "#FFFFFF", fontSize: 29, fontWeight: "900" },
  loadingTitle: { fontSize: 18, fontWeight: "900" },
  topBar: { minHeight: 64, borderBottomWidth: 1, paddingHorizontal: 13, paddingVertical: 9, alignItems: "center", gap: 10 },
  brandIcon: { width: 44, height: 44, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  brandIconText: { color: "#FFFFFF", fontSize: 15, fontWeight: "900" },
  brandName: { fontSize: 15, fontWeight: "900" },
  brandSubtitle: { marginTop: 2, fontSize: 9, fontWeight: "700" },
  statusBadge: { flexDirection: "row", alignItems: "center", gap: 5, minHeight: 28, borderRadius: 999, paddingHorizontal: 9 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: 8, fontWeight: "900" },
  contentArea: { flex: 1 },
  bottomBar: { position: "absolute", left: 8, right: 8, bottom: 7, minHeight: 68, borderWidth: 1, borderRadius: 24, padding: 6, flexDirection: "row", gap: 4, shadowColor: "#000", shadowOpacity: 0.12, shadowOffset: { width: 0, height: 8 }, shadowRadius: 20, elevation: 8 },
  tabButton: { flex: 1, minHeight: 54, borderRadius: 18, alignItems: "center", justifyContent: "center", gap: 3, paddingHorizontal: 2 },
  tabIcon: { fontSize: 18, fontWeight: "900" },
  tabLabel: { maxWidth: "100%", fontSize: 8, fontWeight: "900", textAlign: "center" },
});
